package net.santosh.springboot.exception;

public class ModelAddException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ModelAddException(String message) {
		super(message);
	
	}
}
