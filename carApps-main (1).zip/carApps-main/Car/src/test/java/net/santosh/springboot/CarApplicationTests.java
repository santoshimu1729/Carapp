package net.santosh.springboot;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarApplicationTests {

	@Test
	void contextLoads() {
	}

}
